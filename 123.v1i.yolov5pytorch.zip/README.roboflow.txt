
123 - v1 2022-06-02 11:26pm
==============================

This dataset was exported via roboflow.ai on June 2, 2022 at 8:31 PM GMT

It includes 100 images.
123 are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


